import * as React from 'react';
export default class Test extends React.Component {
    render(): JSX.Element;
}
//# sourceMappingURL=Test.d.ts.map