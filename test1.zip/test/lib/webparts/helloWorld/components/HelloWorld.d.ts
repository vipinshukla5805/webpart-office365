import * as React from 'react';
import { IHelloWorldProps } from './IHelloWorldProps';
export default class HelloWorld extends React.Component<IHelloWorldProps, {}> {
    constructor(props: any);
    state: {
        states: any;
        countries: any;
        save: {};
        edit: {};
        edit2: {};
        delete: {};
        plus: {};
        delete1: {};
        delete2: {};
        delete3: {};
        comments: any;
        documents: any;
        selectedComment: {};
        tComments: any[];
        selectedDocument: {};
        tDocuments: any[];
        selected: any[];
        selectedCountry: number;
        zipvalidator: boolean;
    };
    refe2: any;
    refe1: any;
    iconOver: (type: any) => void;
    iconOut: (type: any) => void;
    selectComment: (event: any, row: any) => void;
    selectDocument: (event: any, row: any) => void;
    changeComment: (event: any) => void;
    changeDocument: (event: any) => void;
    saveComments: () => void;
    saveDocuments: () => void;
    selectCountry: (e: any) => void;
    getValidator: (e: any) => void;
    render(): React.ReactElement<IHelloWorldProps>;
}
//# sourceMappingURL=HelloWorld.d.ts.map